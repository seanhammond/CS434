package assignment3;

//Hold 2d array of x and 1d matrix/array

public class MatrixPac {
	public double [][] x_values;
	public double [] y_values;
}
